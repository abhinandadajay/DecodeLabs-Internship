import pandas as pd

def generate_ux_dashboard_data(file_path):
    print("=" * 50)
    print("📊 UX DASHBOARD DATA METRICS")
    print("=" * 50)
    
    try:
        # Load your file
        df = pd.read_excel(file_path)
        
        # 1. Total Orders
        total_orders = len(df)
        
        # 2. Total Items Sold
        total_items_sold = df['Quantity'].sum()
        
        # 3. Total Sales Revenue (Quantity multiplied by Price for each row)
        df['Total_Sales_Per_Item'] = df['Quantity'] * df['Price']
        total_revenue = df['Total_Sales_Per_Item'].sum()
        
        # Print out your data cards
        print(f"💰 TOTAL REVENUE   : ${total_revenue:,.2f}")
        print(f"📦 TOTAL ORDERS    : {total_orders}")
        print(f"🛒 TOTAL ITEMS SOLD: {total_items_sold}")
        
        # 4. Product Leaderboard Breakdown
        print("\n🏆 PRODUCT LEADERBOARD:")
        print("-" * 50)
        product_summary = df.groupby('Product')['Quantity'].sum().sort_values(ascending=False)
        for idx, (product_name, qty) in enumerate(product_summary.items(), 1):
            print(f"  {idx}. {product_name} ({qty} sold)")
            
        print("=" * 50)
        
    except Exception as e:
        print(f"❌ Error matching column headers: {e}")

if __name__ == "__main__":
    generate_ux_dashboard_data("Online-Store-Orders.xlsx")