import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from PIL import Image


def load_data(file_path):
    df = pd.read_excel(file_path)
    df['Total_Sales_Per_Item'] = df['Quantity'] * df['Price']
    return df


def compute_metrics(df):
    return {
        'total_orders': len(df),
        'total_items_sold': int(df['Quantity'].sum()),
        'total_revenue': df['Total_Sales_Per_Item'].sum(),
        'product_summary': df.groupby('Product')['Quantity'].sum().sort_values(ascending=False)
    }


def load_figma_image(figma_image_path):
    Image.MAX_IMAGE_PIXELS = 800_000_000
    with Image.open(figma_image_path) as img:
        img.thumbnail((1200, 900), Image.LANCZOS)
        return img.copy()


def draw_metric_cards(ax, metrics):
    cards = [
        ('TOTAL REVENUE', f"${metrics['total_revenue']:,.2f}", '#1db954', 2.0),
        ('TOTAL ORDERS', str(metrics['total_orders']), '#1a73e8', 5.0),
        ('ITEMS SOLD', str(metrics['total_items_sold']), '#f4a261', 8.0),
    ]
    for label, value, color, x in cards:
        rect = patches.FancyBboxPatch((x - 1.3, 7.0), 2.6, 1.6,
                                      boxstyle="round,pad=0.1",
                                      linewidth=2, edgecolor=color,
                                      facecolor='#1e1e2e')
        ax.add_patch(rect)
        ax.text(x, 8.1, value, fontsize=16, fontweight='bold',
                color=color, ha='center', va='center')
        ax.text(x, 7.4, label, fontsize=8, color='#aaaaaa',
                ha='center', va='center')


def draw_leaderboard(ax, product_summary):
    ax.text(5, 6.3, 'PRODUCT LEADERBOARD', fontsize=12, fontweight='bold',
            color='white', ha='center', va='center')

    colors = ['#1db954', '#1a73e8', '#f4a261', '#e63946', '#a8dadc']
    max_qty = product_summary.max()

    for i, (product, qty) in enumerate(product_summary.items()):
        y = 5.6 - i * 1.1
        bar_width = (qty / max_qty) * 6.5

        ax.text(0.8, y, f'{i+1}.', fontsize=11, color='#aaaaaa',
                ha='center', va='center')
        bar = patches.FancyBboxPatch((1.2, y - 0.25), bar_width, 0.5,
                                     boxstyle="round,pad=0.05",
                                     facecolor=colors[i % len(colors)],
                                     edgecolor='none', alpha=0.85)
        ax.add_patch(bar)
        ax.text(1.4, y, product, fontsize=10, color='white',
                ha='left', va='center', fontweight='bold')
        ax.text(1.2 + bar_width + 0.2, y, f'{qty} sold', fontsize=9,
                color='#aaaaaa', ha='left', va='center')


def render_dashboard(figma_img, metrics):
    fig = plt.figure(figsize=(16, 9), facecolor='#0f1117')

    ax_img = fig.add_axes([0.0, 0.0, 0.45, 1.0])
    ax_img.imshow(figma_img)
    ax_img.axis('off')
    ax_img.set_title('Figma Design Reference', color='white', fontsize=10, pad=6)

    ax_main = fig.add_axes([0.47, 0.0, 0.53, 1.0], facecolor='#0f1117')
    ax_main.set_xlim(0, 10)
    ax_main.set_ylim(0, 10)
    ax_main.axis('off')

    ax_main.text(5, 9.4, 'UX DASHBOARD', fontsize=20, fontweight='bold',
                 color='white', ha='center', va='center')
    ax_main.text(5, 8.9, 'Online Store Metrics', fontsize=11, color='#aaaaaa',
                 ha='center', va='center')

    draw_metric_cards(ax_main, metrics)

    ax_main.plot([0.5, 9.5], [6.6, 6.6], color='#333333', linewidth=1)

    draw_leaderboard(ax_main, metrics['product_summary'])

    plt.savefig('ux_dashboard_output.png', dpi=150, bbox_inches='tight',
                facecolor='#0f1117')
    print("Dashboard saved as ux_dashboard_output.png")
    plt.show()


def generate_ux_dashboard_data(file_path, figma_image_path):
    try:
        df = load_data(file_path)
        metrics = compute_metrics(df)
        figma_img = load_figma_image(figma_image_path)
        render_dashboard(figma_img, metrics)
    except FileNotFoundError as e:
        print(f"File not found: {e}")
    except Exception as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    generate_ux_dashboard_data("Online-Store-Orders.xlsx", "Untitled.png")
